# blender-vse-easy-proxy
[Blender](https://www.blender.org/) addon to create proxy files for Video Sequence Editor (VSE) easily using [FFMPEG](https://ffmpeg.org/)
# Tutorial
https://youtu.be/t-EVhOYGyBY
